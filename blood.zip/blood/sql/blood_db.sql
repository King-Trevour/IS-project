-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2018 at 10:19 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood_db`
--
DROP DATABASE IF EXISTS `blood_db`;
CREATE DATABASE IF NOT EXISTS `blood_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `blood_db`;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `blood_records`;
CREATE TABLE IF NOT EXISTS `blood_records` (
  `bloodId` int(12) NOT NULL AUTO_INCREMENT,
  `record_userId` int(12) NOT NULL,
  `blood_type` varchar(2) NOT NULL,
  `amount` varchar(30) NOT NULL,
  `record_created_date` bigint(10) NOT NULL DEFAULT '0',
  `record_last_update` bigint(10) NOT NULL DEFAULT '0',
  `blood_order` bigint(12) NOT NULL DEFAULT '0',

  PRIMARY KEY (`bloodId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `blood_records`
--

TRUNCATE TABLE `blood_records`;
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `orderId` int(10) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(70) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `location` varchar(80) NOT NULL,
  `order_blood_type` varchar(2) NOT NULL,
  `order_amount` varchar(20) NOT NULL,
  PRIMARY KEY (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `orders`
--

TRUNCATE TABLE `orders`;
-- Dumping data for table `users`


DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `userId` int(12) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `username` varchar(70) NOT NULL,
  `location` varchar(80) NOT NULL,
  `contact` int(10) NOT NULL,
  `password` varchar(60) NOT NULL,
  `createdtime` bigint(10) DEFAULT '0',
  `user_role` varchar(20) DEFAULT '',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
