<?php
require_once "includes/db_connect.php";

$userId = $_GET["userId"];

$spot_Euser = "SELECT * FROM users WHERE userId = '$userId' LIMIT 1";
$edit_res = $conn->query($spot_Euser);
if($edit_res->num_rows < 1){
    header("Location: user_list.php?DontExist");
	exit();
}

$edit_row = $edit_res->fetch_assoc();

include "templates/header.php";
include "templates/nav.php";

?>
    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->


      <div class="container">
        <!-- Example row of columns -->
        <div class="row">
            <div class="col-md-8">
                <h2>Update <?php print $edit_row["fullName"]; ?></h2>
            </div>
        </div>
        <div class="row">
          <div class="col-md-4">

<form method = "POST" action = "data_process/processes.php" autocomplete = "off" accept-charset="UTF-8">
    <div class="form-group">
		<label for="fullName">Full Name</label>
		<input placeholder="Enter your Full Name" class="form-control form-control-md" name="fullName" type="text" id="fullName" value = "<?php print $edit_row["fullName"]; ?>" required />
	</div>
    <div class="form-group">
		<label for="userRole">Choose Role</label>
		<select class="form-control form-control-md" name="userRole"  id="userRole" required />
        <option value = "<?php print $edit_row["user_role"]; ?>" ><?php print $edit_row["user_role"]; ?></option>
        <option value = "Blood Bank" > Blood Bank </option>
        <option value = "Blood Donation Center" > Blood Donation Center </option>

        </select>
	</div>

    <div class="form-group">
		<input type="hidden" name="userId"  value="<?php print $edit_row["userId"]; ?>" />

		<input class="btn btn-primary" type="submit" name="updateUser"  value="Update Now" OnClick = "return confirm('Are you sure you want to change <?php print $edit_row["fullName"]; ?> in the database?')" />
	</div>
          </div>
          <div class="col-md-4">
    <div class="form-group">
		<label for="email">Email Address</label>
		<input placeholder="Enter your email" class="form-control form-control-md" name="email_address" type="email" id="email" value = "<?php print $edit_row["email"]; ?>" required />
	</div>


</form>
          </div>
          <div class="col-md-4">
            <h2>Details</h2>
<form method = "POST" action = "data_process/processes.php" autocomplete = "off" accept-charset="UTF-8">
    <div class="form-group">
		<h5 for="fullName">Full Name: </h5>
		<?php print $edit_row["fullName"]; ?>
	</div>
    <div class="form-group">
		<h5 for="userRole">Choose Role: </h5>
        <?php print $edit_row["user_role"]; ?>
	</div>
    <div class="form-group">
		<h5 for="email">Email Address: </h5>
		<?php print $edit_row["email"]; ?>
	</div>
    <div class="form-group">
		<h5 for="username">UserName: </h5>
		<?php print $edit_row["username"]; ?>
	</div>
</form>
          </div>
        </div>

        <hr>

      </div> <!-- /container -->

<?php
	include "templates/footer.php";
?>
