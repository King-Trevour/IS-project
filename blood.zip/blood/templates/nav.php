    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="#">Enorma Blood Donation </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>


    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-dark" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Enorma Blood Donation</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#about">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#order">Request</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#donation">Donation</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#register">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#donors">Donors</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
            <?php
                if(isset($_SESSION["control"])){

						if($_SESSION["control"]["user_role"] == "Admin"){
					?>
						<li class="nav-item">
							<a class="nav-link" href="user_list.php">Blood Records</a>
						</li>
					<?php
						}
					?>
                <li class="nav-item">
                    <a class="nav-link" href="view_order.php">View Requests</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin.php">CPanel</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="data_process/signOut.php">Sign Out</a>
                </li>
            <?php
                }
            ?>
        </ul>
        <form class="form-inline my-2 my-lg-0">
			<div class = "text-white mr-sm-2">
				<h5>

					<?php
					if(isset($_SESSION["control"])){
						print "Hello " . $_SESSION["control"]["fullName"];
						print " Logged in as " . $_SESSION["control"]["user_role"];
						 }
					?>
				</h5>
			</div>
        </form>
      </div>

    </nav>
