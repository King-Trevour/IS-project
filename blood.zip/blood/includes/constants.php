<?php
    //Creating Constants
    $server = "localhost"; //Your server is normally referred to as localhost. In some cases you may be required to connect to a remote database server, you may use its IP address
    $server_user = "root"; //DBMS user default is root for most systems
    $user_pass = ""; //DBMS user's password XAMPP and WAMPP normally have no password
    $db_name = "blood_db"; //The database you intend to use. It should be existing for your connection to be successful.
?>