<?php

	require_once "includes/session_control.php";
	require_once "includes/db_connect.php";

	include "templates/header.php";
	include "templates/nav.php";
?>

    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container">
          <h1 class="display-3">Create new record</h1>
        </div>
      </div>
      <div class="container">
        <!-- Example row of columns -->

      <div class="row">

        <div class="row">
          <div class="col-md-8">
            <h2>Create New Record</h2>
<form method = "POST" action = "data_process/processes.php" autocomplete = "off" accept-charset="UTF-8">
    <div class="form-group">
		<label for="record_userId">Blood Bank</label>
    <!--
    The input below will just display the current user's full name in a disabled input field. A way to show the person submitting data the author in cation
    -->
        <input placeholder="Enter your Username" class="form-control form-control-md" type="text" id="record_userId" disabled value = "<?php print $_SESSION["control"]["fullName"]; ?>" />
    <!--
    The input below will capture a hidden value of the current user's ID (primary key). The trick is, this ID will be submitted together with the rest of the new article's information. The ID will be as well inserted in the article table as a reference to the users' table to identify the author.
    -->
		<input name="record_userId" type="hidden" id="record_userId" value = "<?php print $_SESSION["control"]["userId"]; ?>" />
	</div>
    <div class="form-group">
		<label for="blood_type">Blood Type</label>
		<input placeholder="Enter the blood type" class="form-control form-control-md" name="blood_type" type="text" id="blood_type" required />
	</div>
    <div class="form-group">
		<label for="amount">Amount</label>
		<input placeholder="Enter amount" class="form-control form-control-md" name="amount" type= "text" id="amount" required />
	</div>

    <div class="form-group">
		<input class="btn btn-primary" type="submit" name="save_record"  value="Save Record">
	</div>
</form>
          </div>


	</div>
      </div> <!-- /container -->
<?php
	include "templates/footer.php";
?>
