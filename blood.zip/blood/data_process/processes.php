<?php
	session_start(); //This line informs this file that we intend to use the session somewhere within these lines of code.

	//The statement below establishes the database connection by importing the code written in db_connect.php located in  includes.
    require_once "../includes/db_connect.php";

   if (isset($_POST["order"])){
	   //In the line above, $_POST["send_message"] is set (isset) to trigger process that will take place with in the curly bracket. That is if $_POST["send_message"] is missing, no process will table place.

	   //P.S.: Note that $_POST is an array if you do  print_r($_POST); after submission, you will be able to see all array elements
    /**********************************************
    The following statements declare variables that have been submitted from the input form $_POST["fullName"] is identical to name = "fullName" in <input type = "text" name = "fullName" />.
	The mysqli_real_escape_string() function escapes special characters in a string and create a legal SQL string to provide security against SQL injection. That is - mysqli_real_escape_string is used to filter entries to prevent possible attacks.
    //$_POST is used to acquire data that was submitted using the POST method from the user's form.
	**************************************************/
	
    $contact = mysqli_real_escape_string($conn, $_POST["contact"]);
    $blood_type = mysqli_real_escape_string($conn, $_POST["blood_type"]);
    $amount = mysqli_real_escape_string($conn, $_POST["amount"]);
    $fullName = mysqli_real_escape_string($conn, $_POST["fullName"]);
    $location = mysqli_real_escape_string($conn, $_POST["location"]);
	/**************************************************
       The statement that follows is a query to insert specific values in specified table message's attributes.
	Note that (msg_fullName, msg_email, msg_subject, msg_fullText, msg_datetime) MUST BE IDENTICAL to the message's table attributes.
	***********************************************/
    $msg_insert = "INSERT INTO orders(fullName, location, contact, order_blood_type,order_amount) VALUES ('$fullName','$location', '$contact', '$amount', '$blood_type')";

	/*********************************
	In the statement below, we invoke the database connection class using $conn and we pass the $msg_insert argument to the query method.
	My wording may not make sense, but it is an OOP concept. Sorry!!
	*********************************/
    if($conn->query($msg_insert) === TRUE){

		/****
		if the data insertion process is successful, the page will be redirected to contact.php, and exit, that is - php won't read any further lines on this process.php
		****/
        header("Location: ../order.php");
        exit();
    }else{
        print "Failed: " . $conn->error;
    }
    /*******************************************
	You can check a MySQLi Object-oriented example on https://www.w3schools.com/php/php_mysql_insert.asp
	*******************************************/
    }
   if (isset($_POST["sign_up"])){

    $fullName = mysqli_real_escape_string($conn, $_POST["fullName"]);
    $email_address = mysqli_real_escape_string($conn, $_POST["email_address"]);
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    $ConfPass = mysqli_real_escape_string($conn, $_POST["ConfPass"]);
    $userRole = mysqli_real_escape_string($conn, $_POST["userRole"]);

	// Set the encryption cost
    $rounds = array( "cost" => 7 );
    /*The default for the rounds variable has been set to 7 here. 7 is good enough in terms of security and the cost of processing the hash is also acceptable. But depending on your system you might want to use a higher value. As you increase this value the time taken to generate, test, or try to brute-force the hash will increase significantly - hard paper for the attacker. Of course your computer might take slightly longer to generated one password hash.
	As computers get faster you will want to increase the cost (which is the number of rounds), and for high security applications you can: increase the rounds; use a more random salt generator; or generate a hash using multiple hashing mechanisms in sequence.*/

    $hash_pass = password_hash($ConfPass, PASSWORD_BCRYPT, $rounds);
    /*******************************************
	Can also use $hash_pass = password_hash($ConfPass, PASSWORD_DEFAULT); this will let PHP use it's default settings (at time of writing, also bcrypt with a cost of 10):
    https://www.the-art-of-web.com/php/blowfish-crypt/
	*******************************************/

    $user_insert = "INSERT INTO users(fullName, email, username, password, createdtime, user_role) VALUES ('$fullName', '$email_address', '$username', '$hash_pass', UNIX_TIMESTAMP(), '$userRole')";

    if($conn->query($user_insert) === TRUE){
        header("Location: ../");
        exit();
        print "Record stored successfully";
    }else{
        print "Failed: " . $conn->error;
    }

    }
    if (isset($_POST["updateUser"])){

    $userId = mysqli_real_escape_string($conn, $_POST["userId"]);
    $fullName = mysqli_real_escape_string($conn, $_POST["fullName"]);
    $email_address = mysqli_real_escape_string($conn, $_POST["email_address"]);
    $userRole = mysqli_real_escape_string($conn, $_POST["userRole"]);

    $user_update = "UPDATE users SET fullName = '$fullName', email = '$email_address', createdtime = UNIX_TIMESTAMP(), user_role = '$userRole' WHERE userId = '$userId' LIMIT 1";

    if($conn->query($user_update) === TRUE){
        header("Location: ../editUser.php");
        exit();
    }else{
        print "Failed: " . $conn->error;
    }

    }
   if (isset($_POST["sign_in"])){
    //In this particular sign in process we need to verify a userName and password.
    $username_entered = mysqli_real_escape_string($conn, $_POST["uName"]);
    $password_entered = mysqli_real_escape_string($conn, $_POST["pWord"]);

    //The  query below will look a matching userName from the users' tables. "LIMIT 1" means we just need to pick ONLY ONE row. Select all (*) records matching the condition in the WHERE close but pick only the first matching record.
    $spot_username = "SELECT * FROM users WHERE username = '$username_entered' LIMIT 1";

    /*****
    After database connection using new mysqli method, database connection object is returned. A query ($spot_username) is passed to connection object's query method. This function returns a result set. Here we call it user results or $user_res
    *****/
    $user_res = $conn->query($spot_username);

    if ($user_res->num_rows > 0){ //Verifying if at least one row (num_rows or in other words number_of_rows is greater than (>) zero ) was found as a result of the select query above.

    /*************************************************************************
Likewise procedural way a row from result set is fetched using fetch_assoc() method.
This method returns a single row of result that we store in a session declared as $_SESSION["control"]. Column names are used as array indexes to access result like a password we do $_SESSION["control"]["password"] or a userId we do $_SESSION["control"]["userId"].
    *************************************************************************/

        $_SESSION["control"] = $user_res->fetch_assoc();

		$password_stored = $_SESSION["control"]["password"];
//For comparing the user entered password with the stored hash there is also a new function:
			if(password_verify($password_entered, $password_stored)){
/*
The password_verify function is designed to mitigate timing attacks and will work with other hash formats, not just Blowfish. It replaces the method above of having to apply crypt to the entered password ourselves for verification.
*/
					header("Location: ../admin.php");
					exit();

				}else{
                   header("Location: ../order.php");
					exit();
					

				}
	}else{
        header("Location: ../");
		exit();
    }

    }

   if (isset($_POST["save_article"])){

    $article_authorId = mysqli_real_escape_string($conn, $_POST["article_authorId"]);
    $article_title = mysqli_real_escape_string($conn, $_POST["article_title"]);
    $article_full_text = mysqli_real_escape_string($conn, $_POST["article_full_text"]);

        //Since the publication field is not mandatory, we need to verify if it contains any data upon submission, ELSE the publication time is set as NOW using time() on line 15
    if(isset($_POST["article_publication_date"])){
        $pub_date = mysqli_real_escape_string($conn, $_POST["article_publication_date"]);
        //Converting the into date into an UNIX_DATETIME()
        $date = new DateTime($pub_date);
        $article_publication_date = strtotime( $date->format('Y-m-d H:i:s') );
    }else{
        $article_publication_date = time();
    }
    // $article_photo = mysqli_real_escape_string($conn, $_POST["article_photo"]);

    $art_insert = "INSERT INTO articles(article_authorId, article_title, article_full_text, article_publication_date, article_created_date, article_last_update) VALUES ('$article_authorId', '$article_title', '$article_full_text', '$article_publication_date', UNIX_TIMESTAMP(), UNIX_TIMESTAMP())";

    if($conn->query($art_insert) === TRUE){
        header("Location: ../add_article.php");
        exit();
    }else{
        print "Failed: " . $conn->error;
    }

    }
?>
