<?php

session_start();
require_once "../includes/db_connect.php";

$userId = $_GET["userId"];

$del_user = "DELETE FROM users WHERE userId = '$userId'";
if($conn->query($del_user) === TRUE){
	 header("Location: ../user_list.php");
	exit();
		}
?>