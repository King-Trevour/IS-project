<?php
    require_once "includes/db_connect.php";

include "templates/header.php";
include "templates/nav.php";

?>

    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container">
          <h1 class="display-3">View users</h1>
        </div>
      </div>
      <div class="container">
        <!-- Example row of columns -->
        <div class="row">
          <div class="col-md-12">
<?php
$userId = $_GET["userId"];
    $select_users = "SELECT * FROM users WHERE userId = '$userId' LIMIT 1";
    $users_res = $conn->query($select_users);
    if ($users_res->num_rows < 1){
       {
     
    header("Location: view_user.php");
	exit();
}


			
		
        }
    else{
        echo 'No data';
    }
?>
          </div>
        </div>

      </div> <!-- /container -->

    </main>
<?php
	include "templates/footer.php";
?>
