<?php

	include "templates/header.php";
    	
	require_once "includes/session_control.php";
	require_once "includes/db_connect.php";

	include "templates/nav.php";
?>

    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container">
          <h1 class="display-3">Admin Control Panel</h1>
        </div>
      </div>
      <div class="container">
        <!-- Example row of columns -->

      <div class="row">
       
            <div class="col-md-3">
                <a href="user_list.php" class="btn btn-sq-lg btn-primary">
                    <i class="fa fa-user fa-5x"></i><br/>
                    view list
                </a>
            </div>
            <div class="col-md-3">
                <a href="editUser.php" class="btn btn-sq-lg btn-warning">
                  <i class="fa fa-user fa-5x"></i><br/>
                  edit user
                </a>
            </div>
            <div class="col-md-3">
            <a href="#" class="btn btn-sq-lg btn-success">
                  <i class="fa fa-user fa-5x"></i><br/>
                  Manage All User List
                </a>
            </div>
            <div class="col-md-3">
                <a href="#" class="btn btn-sq-lg btn-danger">
                  <i class="fa fa-user fa-5x"></i><br/>
                  System Default Factory
                </a>
            </div>
     
	</div>
      </div> <!-- /container -->
<?php
	include "templates/footer.php";
?>