<?php
    require_once "includes/db_connect.php";

include "templates/header.php";
include "templates/nav.php";

?>

    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container">
          <h1 class="display-3">View Orders</h1>
        </div>
      </div>
      <div class="container">
        <!-- Example row of columns -->
        <div class="row">
          <div class="col-md-12">
<?php
    $select_mgs = "SELECT * FROM orders";
    $msg_res = $conn->query($select_orders);
    if ($msg_res->num_rows > 0){
        while($order_row = $order_res->fetch_assoc()){
        ?>
            <h2><?php print $order_row["order_blood_type"]; ?></h2>

           <h6>Ordered on: <?php print date("jS F Y H:i:s", $order_row["order_datetime"]); ?> by <?php print $order_row["fullName"]; ?></h6>

            <p><?php

			$order_fullText = addslashes($order_row["order_amount"]);

			print $shown_string;


			?>
		
        }
    }else{
        echo 'No data';
    }
?>
          </div>
        </div>

      </div> <!-- /container -->

    </main>
<?php
	include "templates/footer.php";
?>
