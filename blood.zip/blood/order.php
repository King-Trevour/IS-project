<?php
    require_once "includes/db_connect.php";

include "templates/header.php";
include "templates/nav.php";

?>
    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container">
          <h1 class="display-3">Make requests</h1>
        </div>
      </div>

      <div class="container">
        <!-- Example row of columns -->
        <div class="row">
          <div class="col-md-8">
            <h2>Request for blood</h2>
<form method = "POST" action = "data_process/processes.php" autocomplete = "off" accept-charset="UTF-8">
    <div class="form-group">
		<label for="fullName">Full Name</label>
		<input placeholder="Enter your Full Name" class="form-control form-control-md" name="fullName" type="text" id="fullName" required autofocus />
	</div>

  <div class="form-group">
  <label for="location">Location</label>
  <input placeholder="Enter your Location" class="form-control form-control-md" name="location" type="text" id="location" required />
</div>
<div class="form-group">
  <label for="contact">Contact</label>
  <input placeholder="Enter your Contact" class="form-control form-control-md" name="contact" type="text" id="contact" required />
</div>
<div class="form-group">
  <label for="blood_type">Blood Type</label>
  <input placeholder="Enter the blood group" class="form-control form-control-md" name="blood_type" type="text" id="blood_type" required />
</div>
<div class="form-group">
 <label for="amount">Amount</label>
  <input placeholder="Enter the amount" class="form-control form-control-md" name="amount" type="text" id="amount" required />
</div>

	<div>
		<input class="btn btn-primary" type="submit" name="order"  value="Order">
	</div>
</form>
          </div>

        </div>

        <hr />

      </div> <!-- /container -->

    </main>

    <footer class="container">
      <p>Copyright &copy; Enorma Blood Donation</p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
  </body>
</html>
