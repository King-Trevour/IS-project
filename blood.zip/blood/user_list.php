<?php
    require_once "includes/db_connect.php";

include "templates/header.php";
include "templates/nav.php";

?>

    <main role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
      <div class="jumbotron">
        <div class="container">
          <h1 class="display-3">User List</h1>
        </div>
      </div>
      <div class="container">
        <!-- Example row of columns -->
	  
	  <table class="table table-striped">
		  <thead>
				<tr>
				  <th scope="col">#</th>
				  <th scope="col">Full Name</th>
				  <th scope="col">Email Address</th>
				  <th scope="col">User Name</th>
				  <th scope="col">User Role</th>
				  <th scope="col">Actions</th>
				</tr>
		  </thead>
		  <?php
$spot_users = "SELECT * FROM users WHERE user_role <> 'Admin'";
$user_res = $conn->query($spot_users);
if($user_res->num_rows > 0){
		?>  
		  <tbody>
<?php
$nCount = 1;
	while($users_row = $user_res->fetch_assoc()){
?>
    <tr>
        <th scope="row"><?php print $nCount; ?></th>
        <td><?php print $users_row["fullName"]; ?></td>
        <td><?php print $users_row["email"]; ?></td>
        <td><?php print $users_row["username"]; ?></td>
        <td><?php print $users_row["user_role"]; ?></td>
    <td>
    [ <a href = "editUser.php?userId=<?php print $users_row["userId"]; ?>" >Edit</a> ]
    
    |
    
    [ <a href = "data_process/userDel.php?userId=<?php print $users_row["userId"]; ?>" OnClick = "return confirm('Are you sure you want to delete <?php print $users_row["fullName"]; ?> from the database?')" >Delete</a> ]
    </td>
    </tr>
<?php
$nCount++;
}
?>
		  </tbody>
<?php
}
?>
		  <tfoot>
		  
		  </tfoot>
	</table>

      </div> <!-- /container -->

    </main>
<?php
	include "templates/footer.php";
?>